
#import <Cocoa/Cocoa.h>
#import "cocos2d.h"

int main(int argc, char *argv[]) {
	[CCGLView load_];
    return NSApplicationMain(argc,  (const char **) argv);
}
