# spine-threejs

spine-threejs has been deprecated and is superseded by [spine-ts THREE.JS backend](https://github.com/EsotericSoftware/spine-runtimes/tree/master/spine-ts). The most recent version of spine-threejs can be found in the [spine-threejs branch](https://github.com/EsotericSoftware/spine-runtimes/tree/spine-threejs/spine-threejs)