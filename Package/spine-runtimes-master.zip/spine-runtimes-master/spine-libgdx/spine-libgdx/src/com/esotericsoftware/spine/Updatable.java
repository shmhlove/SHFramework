
package com.esotericsoftware.spine;

public interface Updatable {
	public void update ();
}
